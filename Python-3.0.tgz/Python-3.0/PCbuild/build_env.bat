@%comspec% /k env.bat %*
